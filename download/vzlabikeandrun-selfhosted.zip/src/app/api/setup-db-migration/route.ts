import { db } from "@/lib/db";
import { NextResponse } from "next/server";

/**
 * GET /api/setup-db-migration
 * Verifica columnas migradas. Con Prisma + `db push` esto ya no es necesario.
 */
export async function GET() {
  try {
    // Just verify the DB connection and schema are in sync
    await db.$queryRaw`SELECT 1`;
    
    return NextResponse.json({
      success: true,
      message: "Database connection OK. Schema is managed by Prisma — run 'npx prisma db push' to sync.",
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err?.message || String(err) },
      { status: 500 }
    );
  }
}
