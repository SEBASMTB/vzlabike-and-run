import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { sql } from "@prisma/client/runtime/library";

// GET - List all categories for an event
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authError = requireAuth(request);
    if (authError) return authError;

    const { id } = await params;

    const event = await db.event.findUnique({ where: { id } });
    if (!event) {
      return NextResponse.json({ error: "Evento no encontrado" }, { status: 404 });
    }

    // Use Prisma ORM instead of raw SQL for database portability
    const categories = await db.eventCategory.findMany({
      where: { eventId: id },
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    });

    return NextResponse.json(
      categories.map((c) => ({
        ...c,
        extraFields: JSON.parse(c.extraFields || "[]"),
      }))
    );
  } catch {
    return NextResponse.json(
      { error: "Error al obtener categorías" },
      { status: 500 }
    );
  }
}

// POST - Create a category for an event
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authError = requireAuth(request);
    if (authError) return authError;

    const { id } = await params;
    const body = await request.json();

    const {
      name,
      code,
      discipline = "",
      gender = "",
      minAge = 0,
      maxAge = 999,
      profileType = "",
      sortOrder = 0,
      extraFields = [],
    } = body;

    if (!name || !code) {
      return NextResponse.json(
        { error: "Nombre y código son requeridos" },
        { status: 400 }
      );
    }

    const category = await db.eventCategory.create({
      data: {
        eventId: id,
        name,
        code,
        discipline,
        gender,
        minAge,
        maxAge,
        profileType,
        sortOrder,
        extraFields: JSON.stringify(extraFields),
      },
    });

    return NextResponse.json(
      {
        ...category,
        extraFields,
      },
      { status: 201 }
    );
  } catch {
    return NextResponse.json(
      { error: "Error al crear categoría" },
      { status: 500 }
    );
  }
}

// PUT - Update a category
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authError = requireAuth(request);
    if (authError) return authError;

    const { id: eventId } = await params;
    const body = await request.json();

    const {
      categoryId,
      name,
      code,
      discipline,
      gender,
      minAge,
      maxAge,
      profileType,
      sortOrder,
      extraFields,
    } = body;

    if (!categoryId) {
      return NextResponse.json(
        { error: "categoryId es requerido" },
        { status: 400 }
      );
    }

    const updateData: Record<string, any> = {};
    if (name !== undefined) updateData.name = name;
    if (code !== undefined) updateData.code = code;
    if (discipline !== undefined) updateData.discipline = discipline;
    if (gender !== undefined) updateData.gender = gender;
    if (minAge !== undefined) updateData.minAge = minAge;
    if (maxAge !== undefined) updateData.maxAge = maxAge;
    if (profileType !== undefined) updateData.profileType = profileType;
    if (sortOrder !== undefined) updateData.sortOrder = sortOrder;
    if (extraFields !== undefined) updateData.extraFields = JSON.stringify(extraFields);

    await db.eventCategory.updateMany({
      where: { id: categoryId, eventId },
      data: updateData,
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Error al actualizar categoría" },
      { status: 500 }
    );
  }
}

// DELETE - Delete a category
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authError = requireAuth(request);
    if (authError) return authError;

    const { id: eventId } = await params;
    const { searchParams } = new URL(request.url);
    const categoryId = searchParams.get("categoryId");

    if (!categoryId) {
      return NextResponse.json(
        { error: "categoryId es requerido" },
        { status: 400 }
      );
    }

    await db.eventCategory.deleteMany({
      where: { id: categoryId, eventId },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Error al eliminar categoría" },
      { status: 500 }
    );
  }
}

// PATCH - Toggle active status
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authError = requireAuth(request);
    if (authError) return authError;

    const { id: eventId } = await params;
    const body = await request.json();

    const { categoryId, active } = body;

    if (!categoryId || active === undefined) {
      return NextResponse.json(
        { error: "categoryId y active son requeridos" },
        { status: 400 }
      );
    }

    await db.eventCategory.updateMany({
      where: { id: categoryId, eventId },
      data: { active: Boolean(active) },
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Error al actualizar estado de categoría" },
      { status: 500 }
    );
  }
}
