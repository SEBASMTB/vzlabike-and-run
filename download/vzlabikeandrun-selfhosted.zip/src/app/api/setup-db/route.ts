import { db } from "@/lib/db";
import { NextResponse } from "next/server";

/**
 * GET /api/setup-db
 * Verifica y crea tablas necesarias usando Prisma.
 * Compatible con PostgreSQL, MySQL y SQLite.
 */
export async function GET() {
  const results: string[] = [];

  try {
    // Con Prisma y `prisma db push`, las tablas se crean automáticamente
    // desde schema.prisma. Este endpoint ahora solo verifica la conexión.
    
    try {
      await db.$queryRaw`SELECT 1`;
      results.push("Conexión a base de datos exitosa");
    } catch {
      results.push("ERROR: No se pudo conectar a la base de datos");
      return NextResponse.json(
        { success: false, message: "Database connection failed", results },
        { status: 500 }
      );
    }

    // Verify tables exist by counting records
    try {
      const eventCount = await db.event.count();
      results.push(`Tabla Event OK (${eventCount} registros)`);
    } catch (err: any) {
      results.push(`Tabla Event: ${err?.message}`);
    }

    try {
      const regCount = await db.registration.count();
      results.push(`Tabla Registration OK (${regCount} registros)`);
    } catch (err: any) {
      results.push(`Tabla Registration: ${err?.message}`);
    }

    try {
      const prodCount = await db.product.count();
      results.push(`Tabla Product OK (${prodCount} registros)`);
    } catch (err: any) {
      results.push(`Tabla Product: ${err?.message}`);
    }

    try {
      const orderCount = await db.productOrder.count();
      results.push(`Tabla ProductOrder OK (${orderCount} registros)`);
    } catch (err: any) {
      results.push(`Tabla ProductOrder: ${err?.message}`);
    }

    try {
      const catCount = await db.eventCategory.count();
      results.push(`Tabla EventCategory OK (${catCount} registros)`);
    } catch (err: any) {
      results.push(`Tabla EventCategory: ${err?.message}`);
    }

    return NextResponse.json({
      success: true,
      message: "Database verification complete. Run 'npx prisma db push' to sync schema.",
      results,
    });
  } catch (err) {
    return NextResponse.json(
      { success: false, error: String(err), results },
      { status: 500 }
    );
  }
}
