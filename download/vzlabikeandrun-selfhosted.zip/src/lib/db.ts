import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
  dbSeeded: boolean | undefined
}

// ── Seed data (8 events, NEVER modify) ──────────────────────────────────────

const SEED_EVENTS = [
  {
    id: "evt-la-culata-001",
    title: "LA CULATA",
    slug: "la-culata-2025",
    description: "Evento MTB en las montañas de La Culata. Un desafío para ciclistas de montaña con recorridos técnicos y paisajes espectaculares en plena serranía venezolana.",
    date: "2025-07-20T06:00:00.000Z",
    location: "La Culata, Mérida, Venezuela",
    distance: "40K MTB",
    category: "MTB",
    sportType: "mtb",
    imageUrl: "",
    bannerImage: "",
    price: 55,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 300,
    featured: true,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "event_day",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "evt-campana-admirable-001",
    title: "CAMPAÑA ADMIRABLE",
    slug: "campana-admirable-2025",
    description: "Carrera conmemorativa de la Campaña Admirable. Une la historia y el deporte en este recorrido que celebra el legado de Bolívar. Una experiencia única para corredores y familias.",
    date: "2025-06-15T06:00:00.000Z",
    location: "Venezuela",
    distance: "10K",
    category: "Carrera",
    sportType: "running",
    imageUrl: "",
    bannerImage: "",
    price: 30,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 1500,
    featured: true,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "cmouqk7300000peaj68nvak7u",
    title: "WOMENS RUN",
    slug: "womens-run-2024",
    description: "La carrera más grande de mujeres en Venezuela. Únete a miles de corredoras en esta emocionante prueba de 5K. Un evento diseñado para celebrar la fuerza, determinación y espíritu deportivo de la mujer venezolana.",
    date: "2026-06-06T00:16:23.770Z",
    location: "Caracas, Venezuela",
    distance: "5K",
    category: "Carrera",
    sportType: "running",
    imageUrl: "/event-womens-run.jpg",
    bannerImage: "",
    price: 35,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 2000,
    featured: true,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "cmouqk7320001peaj38mchqx3",
    title: "21K LA AUTOPISTA",
    slug: "21k-la-autopista",
    description: "La media maratón más emblemática del país. Recorre la autopista en una experiencia única con cierre total de vías. Miles de corredores disfrutan de este evento que combina deportividad y espectacularidad.",
    date: "2026-08-23T00:16:23.770Z",
    location: "Autopista Regional del Centro, Venezuela",
    distance: "21K",
    category: "Carrera",
    sportType: "running",
    imageUrl: "/event-21k-autopista.jpg",
    bannerImage: "",
    price: 65,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 5000,
    featured: true,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "cmouqk7330002peajacov64kx",
    title: "FARMALUNA 10K",
    slug: "farmaluna-10k-2024",
    description: "Corre bajo la luz de la luna en esta mágica carrera nocturna. La Farmaluna 10K te ofrece una experiencia diferente con iluminación especial, música en vivo y un ambiente incomparable.",
    date: "2026-05-22T00:16:23.770Z",
    location: "Caracas, Venezuela",
    distance: "10K",
    category: "Carrera",
    sportType: "running",
    imageUrl: "/event-farmaluna.jpg",
    bannerImage: "",
    price: 45,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 3000,
    featured: false,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "cmouqk7340003peajm6kd9t8x",
    title: "LA RUTA DIGITAL",
    slug: "la-ruta-digital-2024",
    description: "El primer evento virtual integrado con tecnología de punta. Corre desde cualquier lugar, registra tu recorrido y compite con atletas de todo el país. Resultados en tiempo real a través de nuestra plataforma VBRWorks.",
    date: "2026-06-07T00:16:23.770Z",
    location: "Virtual - Desde cualquier lugar",
    distance: "10K Virtual",
    category: "Virtual",
    sportType: "running",
    imageUrl: "/event-ruta-digital.jpg",
    bannerImage: "",
    price: 25,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 10000,
    featured: false,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "cmouqk7350004peajb9ekzxqd",
    title: "MARATÓN DE CARACAS",
    slug: "maraton-caracas-2024",
    description: "El maratón más importante de Venezuela. 42 kilómetros de pura emoción recorriendo las calles más emblemáticas de la capital. Un desafío para los corredores más exigentes.",
    date: "2026-07-06T00:16:23.770Z",
    location: "Caracas, Venezuela",
    distance: "42K",
    category: "Carrera",
    sportType: "running",
    imageUrl: "/event-maraton-caracas.jpg",
    bannerImage: "",
    price: 85,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 4000,
    featured: false,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
  {
    id: "cmouqk7360005peajp7h5ns41",
    title: "TRIATLÓN VZLA",
    slug: "triatlon-vzla-2024",
    description: "El triatlón más completo de Venezuela. Distancia olímpica: 1.5km de natación, 40km de ciclismo y 10km de carrera. Un evento para atletas que buscan superar sus límites en tres disciplinas.",
    date: "2026-08-05T00:16:23.770Z",
    location: "Valencia, Venezuela",
    distance: "Distancia Olímpica",
    category: "Triatlón",
    sportType: "running",
    imageUrl: "/event-triatlon.jpg",
    bannerImage: "",
    price: 120,
    priceBs: 0,
    status: "upcoming",
    maxParticipants: 500,
    featured: false,
    organizer: "",
    prizes: "",
    rules: "",
    kitInfo: "",
    sponsors: "",
    categories: "",
    ageCalcMode: "calendar_year",
    categoryInterval: "10",
    hasShirt: true,
  },
];

// ── Initialization (single source of truth, runs once) ─────────────────────

let initPromise: Promise<void> | null = null;

async function initAndSeed(prisma: PrismaClient) {
  if (globalForPrisma.dbSeeded) return;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    try {
      // Run Prisma migrations / push schema
      // In self-hosted mode, tables are created by `prisma db push` or `prisma migrate`
      // so we only need to seed data

      // Seed events ONLY if the table is completely empty
      const count = await prisma.event.count();
      if (count === 0) {
        for (const event of SEED_EVENTS) {
          await prisma.event.create({
            data: {
              ...event,
              createdAt: new Date("2026-05-07T00:16:23.772Z"),
              updatedAt: new Date("2026-05-07T00:16:23.772Z"),
            },
          });
        }
      }

      globalForPrisma.dbSeeded = true;
    } catch (err) {
      console.error("[DB] Error al inicializar:", err);
      globalForPrisma.dbSeeded = false;
      initPromise = null;
    }
  })();

  return initPromise;
}

// ── Prisma client factory (supports PostgreSQL, MySQL, SQLite) ──────────

function createPrismaClient(): PrismaClient {
  // Standard PrismaClient — uses DATABASE_URL from .env
  // Works with PostgreSQL, MySQL, or SQLite depending on schema.prisma provider
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  })
}

// ── Singleton ──────────────────────────────────────────────────────────────

const _prismaClient =
  globalForPrisma.prisma ??
  createPrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = _prismaClient

let dbReadyPromise: Promise<void> | null = null;

export async function getDb(): Promise<PrismaClient> {
  if (globalForPrisma.dbSeeded) return _prismaClient;

  if (!dbReadyPromise) {
    dbReadyPromise = initAndSeed(_prismaClient);
  }
  await dbReadyPromise;
  return _prismaClient;
}

export const db = new Proxy(_prismaClient, {
  get(target, prop) {
    if (prop === 'then' || prop === 'toJSON' || typeof prop === 'symbol') {
      return Reflect.get(target, prop);
    }
    const value = (target as any)[prop];
    if (typeof value !== 'function') return value;

    if (process.env.NODE_ENV === 'production') {
      return function(this: any, ...args: any[]) {
        const self = this === db ? target : this;
        if (!globalForPrisma.dbSeeded) {
          if (!dbReadyPromise) {
            dbReadyPromise = initAndSeed(target);
          }
          return dbReadyPromise.then(() => value.apply(self, args));
        }
        return value.apply(self, args);
      };
    }
    return value.bind(target);
  }
});

if (process.env.NODE_ENV === 'production') {
  dbReadyPromise = initAndSeed(_prismaClient).catch(console.error);
}
