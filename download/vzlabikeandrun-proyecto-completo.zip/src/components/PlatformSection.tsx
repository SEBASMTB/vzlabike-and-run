"use client";

import { motion } from "framer-motion";
import {
  Monitor,
  Users,
  CreditCard,
  BarChart3,
  QrCode,
  Shield,
  Smartphone,
  Globe,
  ArrowRight,
  ExternalLink,
  Trophy,
  Clock,
  Activity,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "./SectionHeading";

const RESULTS_URL = "https://vbr-results-portal.vercel.app";

const platformFeatures = [
  {
    icon: Users,
    title: "Inscripciones",
    description: "Registro online con categorización automática inteligente por edad, género y disciplina.",
    stat: "15,000+",
    statLabel: "Inscripciones gestionadas",
  },
  {
    icon: BarChart3,
    title: "Resultados en Vivo",
    description: "Publicación instantánea con tiempos parciales, clasificaciones y estadísticas en tiempo real.",
    stat: "98.5%",
    statLabel: "Precisión de lectura",
  },
  {
    icon: CreditCard,
    title: "Pagos Integrados",
    description: "Binance, Zelle, Pago Móvil y Transferencia. Confirmación automática en 24-48 horas.",
    stat: "4",
    statLabel: "Pasarelas de pago",
  },
  {
    icon: QrCode,
    title: "Check-in Digital",
    description: "Lectura QR rápida para acreditación de participantes el día del evento.",
    stat: "< 3s",
    statLabel: "Por check-in",
  },
  {
    icon: Trophy,
    title: "Clasificaciones",
    description: "Ranking automático por categoría, género, edad y tiempos parciales en cada punto de control.",
    stat: "100+",
    statLabel: "Categorías soportadas",
  },
  {
    icon: Shield,
    title: "Seguridad Total",
    description: "Datos protegidos con encriptación, respaldo en la nube y monitoreo 24/7.",
    stat: "99.9%",
    statLabel: "Uptime",
  },
  {
    icon: Smartphone,
    title: "App Móvil",
    description: "Resultados al instante desde cualquier dispositivo. Comparte tus tiempos en redes sociales.",
    stat: "24/7",
    statLabel: "Disponibilidad",
  },
  {
    icon: Globe,
    title: "Páginas Personalizadas",
    description: "Landing pages profesionales para cada evento con branding del organizador.",
    stat: "500+",
    statLabel: "Eventos realizados",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function PlatformSection() {
  return (
    <section id="resultados" className="py-20 md:py-28 gradient-dark text-white overflow-hidden relative">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-full" style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
          backgroundSize: "40px 40px"
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeading
          title="VBRWorks®"
          subtitle="Plataforma integral de gestión de eventos deportivos. Potencia tu evento con la tecnología más avanzada del mercado venezolano."
          light
        />

        {/* Live Results Preview */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
            {/* Browser chrome */}
            <div className="flex items-center gap-2 px-4 py-3 bg-white/5 border-b border-white/10">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>
              <div className="flex-1 flex justify-center">
                <div className="bg-white/10 rounded-md px-4 py-1 text-xs text-white/60 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  vbr-results-portal.vercel.app
                </div>
              </div>
            </div>

            {/* Dashboard preview */}
            <div className="bg-[#0f172a] p-6 md:p-8">
              {/* Stats row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="size-4 text-blue-400" />
                    <span className="text-xs text-white/50">Participantes</span>
                  </div>
                  <div className="text-2xl font-bold text-white">1,247</div>
                </div>
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="size-4 text-green-400" />
                    <span className="text-xs text-white/50">Lecturas OK</span>
                  </div>
                  <div className="text-2xl font-bold text-green-400">98.5%</div>
                </div>
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <QrCode className="size-4 text-amber-400" />
                    <span className="text-xs text-white/50">Puntos Control</span>
                  </div>
                  <div className="text-2xl font-bold text-white">5</div>
                </div>
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="size-4 text-red-400" />
                    <span className="text-xs text-white/50">En Vivo</span>
                  </div>
                  <div className="text-2xl font-bold text-red-400 flex items-center gap-2">
                    NOW
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  </div>
                </div>
              </div>

              {/* Results table */}
              <div className="bg-white/5 rounded-xl border border-white/5 overflow-hidden">
                <div className="flex items-center justify-between px-5 py-3 border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <Trophy className="size-4 text-yellow-400" />
                    <span className="text-sm font-semibold">Clasificación General</span>
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[10px]">
                    Tiempo real
                  </Badge>
                </div>
                <div className="divide-y divide-white/5">
                  <div className="flex items-center text-xs text-white/40 px-5 py-2">
                    <span className="w-10">#</span>
                    <span className="w-8"></span>
                    <span className="flex-1">Atleta</span>
                    <span className="w-20 text-right hidden sm:block">Categoría</span>
                    <span className="w-16 text-right">Tiempo</span>
                    <span className="w-14 text-right hidden sm:block">Pace</span>
                  </div>
                  {[
                    { pos: 1, name: "Carlos Rodríguez", cat: "Élite M", time: "32:15", pace: "4:35", medal: "🥇" },
                    { pos: 2, name: "María González", cat: "Libre F", time: "34:22", pace: "4:54", medal: "🥈" },
                    { pos: 3, name: "José Martínez", cat: "Sub-23 M", time: "35:08", pace: "5:01", medal: "🥉" },
                    { pos: 4, name: "Ana López", cat: "Máster A F", time: "36:45", pace: "5:14", medal: "" },
                    { pos: 5, name: "Pedro Hernández", cat: "Élite M", time: "37:12", pace: "5:19", medal: "" },
                  ].map((row) => (
                    <div
                      key={row.pos}
                      className={`flex items-center px-5 py-2.5 text-sm ${row.pos <= 3 ? "bg-white/[0.03]" : ""}`}
                    >
                      <span className="w-10 font-bold text-red-400">{row.pos}</span>
                      <span className="w-8">{row.medal}</span>
                      <span className="flex-1 text-white/90 font-medium">{row.name}</span>
                      <span className="w-20 text-right text-white/50 hidden sm:block text-xs">{row.cat}</span>
                      <span className="w-16 text-right text-white/80 font-mono">{row.time}</span>
                      <span className="w-14 text-right text-white/50 font-mono hidden sm:block">{row.pace}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Feature Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12"
        >
          {platformFeatures.map((feature) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 group"
            >
              <div className="flex items-start justify-between mb-3">
                <feature.icon className="size-8 text-red-400 group-hover:scale-110 transition-transform" />
                {feature.stat && (
                  <span className="text-lg font-bold text-white/90">{feature.stat}</span>
                )}
              </div>
              <h3 className="text-sm font-semibold mb-1">{feature.title}</h3>
              <p className="text-xs text-white/50 leading-relaxed mb-2">
                {feature.description}
              </p>
              {feature.statLabel && (
                <span className="text-[10px] text-white/30">{feature.statLabel}</span>
              )}
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href={RESULTS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-white text-[#1A1A2E] px-8 h-12 rounded-lg text-base font-semibold hover:bg-gray-100 transition-colors"
          >
            Abrir Plataforma de Resultados
            <ExternalLink className="size-4" />
          </a>
          <Button
            size="lg"
            className="bg-white/10 text-white border border-white/20 hover:bg-white/20 text-base px-8 h-12"
            onClick={() => { window.location.href = "/resultados"; }}
          >
            <Monitor className="size-4 mr-2" />
            Ver en Pantalla Completa
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
