"use client";

import { motion } from "framer-motion";
import {
  Timer,
  BarChart3,
  Split,
  MapPin,
  Share2,
  Globe,
  Tag,
  Bike,
  FootprintsIcon,
  MonitorSmartphone,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Radio,
} from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const timingServices = [
  {
    icon: Timer,
    title: "Cronometraje de Eventos",
    description: "Sistema de cronometraje de alta precisión con tecnología RFID para resultados exactos hasta la milésima de segundo.",
  },
  {
    icon: BarChart3,
    title: "Resultados en Tiempo Real",
    description: "Publicación instantánea de resultados en línea durante el desarrollo del evento con actualizaciones automáticas.",
  },
  {
    icon: Split,
    title: "Tiempos Parciales",
    description: "Registros de tiempos intermedios en puntos clave del recorrido para análisis de rendimiento.",
  },
  {
    icon: MapPin,
    title: "Seguimiento de Atletas",
    description: "Tracking en vivo de cada participante a lo largo del recorrido con geolocalización.",
  },
  {
    icon: Share2,
    title: "Actualizaciones en Redes Sociales",
    description: "Publicación automática de resultados y highlights en redes sociales en tiempo real.",
  },
  {
    icon: Globe,
    title: "Página de Resultados Personalizada",
    description: "Página web dedicada al evento con resultados, fotos, estadísticas y clasificaciones.",
  },
];

const equipmentProducts = [
  {
    icon: Tag,
    title: "TAG Multisport",
    description: "Chip RFID diseñado para triatlón y carreras de fondo. Resistente al agua, alta durabilidad y lectura garantizada.",
    badge: "Triatlón / Carrera",
    badgeColor: "bg-emerald-100 text-emerald-700",
    features: ["Resistencia al agua IP68", "Lectura bidireccional", "Hasta 10,000 ciclos"],
    imageGradient: "from-emerald-500 to-teal-600",
  },
  {
    icon: Bike,
    title: "TAG Road-MTB",
    description: "Chip especial para ciclismo de ruta y montaña. Montaje seguro en horquilla con máxima precisión de lectura.",
    badge: "Ciclismo",
    badgeColor: "bg-amber-100 text-amber-700",
    features: ["Montaje en horquilla", "Anti-vibración", "Lectura a alta velocidad"],
    imageGradient: "from-amber-500 to-orange-600",
  },
  {
    icon: FootprintsIcon,
    title: "Custom Shoe Tag",
    description: "TAG personalizado para calzado deportivo. Cómodo, discreto y fácil de colocar en cualquier zapatilla.",
    badge: "Running",
    badgeColor: "bg-red-100 text-red-700",
    features: ["Ultra ligero (3g)", "Ajuste universal", "Personalizable"],
    imageGradient: "from-red-500 to-rose-600",
  },
  {
    icon: MonitorSmartphone,
    title: "VBRWorks Platform",
    description: "Plataforma integral de gestión de eventos deportivos. Incripciones online, resultados en vivo y administración completa.",
    badge: "Software",
    badgeColor: "bg-violet-100 text-violet-700",
    features: ["Gestión integral", "Resultados en vivo", "Multi-evento"],
    imageGradient: "from-violet-500 to-purple-600",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function ServicesSection() {
  return (
    <section id="servicios" className="py-20 md:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Timing & Technology */}
        <SectionHeading
          title="Nuestros Servicios"
          subtitle="Ofrecemos soluciones integrales para la gestión y cronometraje de eventos deportivos con tecnología de punta."
        />

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20"
        >
          {timingServices.map((service) => (
            <motion.div key={service.title} variants={itemVariants}>
              <Card className="h-full hover:shadow-lg hover:border-red-200 transition-all duration-300 group">
                <CardContent className="p-6">
                  <div className="w-12 h-12 gradient-primary rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <service.icon className="size-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Equipment & Products — Enhanced */}
        <div className="mb-12">
          <SectionHeading
            title="Equipamiento y Productos"
            subtitle="Tecnología de vanguardia para garantizar la mejor experiencia en cronometraje deportivo. Productos diseñados y probados en más de 500 eventos."
          />
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {equipmentProducts.map((product) => (
            <motion.div key={product.title} variants={itemVariants}>
              <Card className="h-full overflow-hidden hover:shadow-xl transition-all duration-300 border hover:border-red-200 group">
                {/* Product Visual Header */}
                <div className={`relative h-44 bg-gradient-to-br ${product.imageGradient} p-6 flex flex-col justify-between`}>
                  <div className="flex items-start justify-between">
                    <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3">
                      <product.icon className="size-8 text-white" />
                    </div>
                    <Badge className={`${product.badgeColor} border-0 font-medium`}>
                      {product.badge}
                    </Badge>
                  </div>
                  {/* Decorative elements */}
                  <div className="absolute bottom-0 right-0 opacity-10">
                    <Radio className="size-32 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{product.title}</h3>
                  </div>
                </div>

                <CardContent className="p-6">
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    {product.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-2 mb-4">
                    {product.features.map((feature) => (
                      <div key={feature} className="flex items-center gap-2">
                        <CheckCircle2 className="size-4 text-green-500 shrink-0" />
                        <span className="text-xs text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  {product.title === "VBRWorks Platform" ? (
                    <a
                      href="https://vbr-results-portal.vercel.app"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-semibold text-red-600 hover:text-red-700 transition-colors"
                    >
                      Ir a la plataforma
                      <ArrowRight className="size-4" />
                    </a>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => { window.location.href = "/tienda"; }}
                    >
                      Ver en Tienda
                      <ArrowRight className="size-3 ml-1" />
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
